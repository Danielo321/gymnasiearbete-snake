// För att köra server1.js se till så att du är i rätt filväg.
// cd C:\Users\Daniel\Desktop\Gymnasiearbete\Spel\Spel-enkel
// node server1.js

// Importera de nödvändiga modulerna
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const app = express();
const port = 3001; // Samma port som server2.js för enhetlighet

// Använd CORS för att tillåta förfrågningar från alla ursprung
app.use(cors());

// Middleware för att läsa JSON-data i POST-förfrågningar
app.use(express.json());

// Filvägar för att spara highscore och speldata i Spel-enkel
const highscoreFilePath = path.join(__dirname, 'highscore.json');
const gameDataFilePath = path.join(__dirname, 'gameData.json');

// Funktion för att läsa JSON-fil och hantera fel
const readJsonFile = (filePath, defaultValue, res, callback) => {
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            if (err.code === 'ENOENT') {
                // Filen finns inte, skapa en ny med standardvärde
                fs.writeFile(filePath, JSON.stringify(defaultValue, null, 2), (writeErr) => {
                    if (writeErr) {
                        console.error(`Error creating file ${filePath}:`, writeErr);
                        return res.status(500).send(`Failed to create ${filePath}`);
                    }
                    return callback(defaultValue);
                });
            } else {
                console.error(`Error reading file ${filePath}:`, err);
                return res.status(500).send(`Failed to read ${filePath}`);
            }
        } else {
            try {
                const jsonData = JSON.parse(data);
                callback(jsonData);
            } catch (parseErr) {
                console.error(`Error parsing JSON from ${filePath}:`, parseErr);
                return res.status(500).send(`Error parsing JSON from ${filePath}`);
            }
        }
    });
};

// Endpoint för att hämta highscore
app.get('/get-highscore', (req, res) => {
    readJsonFile(highscoreFilePath, { highscore: 0 }, res, (highscoreData) => {
        res.json(highscoreData);
    });
});

// Endpoint för att spara speldata
app.post('/save-game', (req, res) => {
    const gameData = req.body;
    console.log('Game data received:', gameData);

    // Lägg till nödvändiga fält om de inte finns
    const gameDataWithVersion = {
        gameVersion: gameData.gameVersion || "Powerup-version", // Exempel: "snake" eller "version2"
        score: gameData.score || 0,
        highscore: gameData.highscore || 0, // Säkerställ att highscore finns
        time: gameData.time || 0, // Lägg till default time om inget anges
        date: gameData.date || new Date().toISOString(), // Sätt aktuellt datum om inget anges
        note: gameData.note || "Great game! Keep improving!", // Sätt default not om inget anges

    };

    readJsonFile(gameDataFilePath, [], res, (gameDataArray) => {
        // Lägg till den nya spelomgången till arrayen
        gameDataArray.push(gameDataWithVersion);

        // Skriv tillbaka den uppdaterade arrayen till filen
        fs.writeFile(gameDataFilePath, JSON.stringify(gameDataArray, null, 2), (err) => {
            if (err) {
                console.error(`Error saving game data to ${gameDataFilePath}:`, err);
                return res.status(500).send('Failed to save game data');
            }
            console.log(`Game data saved to ${gameDataFilePath}`);
            res.send('Game data saved');
        });
    });
});

// Endpoint för att uppdatera highscore
app.post('/update-highscore', (req, res) => {
    const { highscore } = req.body;
    console.log('Updating highscore:', highscore);

    const highscoreData = JSON.stringify({ highscore: highscore }, null, 2);

    fs.writeFile(highscoreFilePath, highscoreData, (err) => {
        if (err) {
            console.error(`Error saving highscore to ${highscoreFilePath}:`, err);
            return res.status(500).send('Failed to update highscore');
        }
        console.log(`Highscore updated in ${highscoreFilePath}`);
        res.send('Highscore updated');
    });
});

// Starta servern
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
