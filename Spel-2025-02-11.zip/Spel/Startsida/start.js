document.getElementById("version1").addEventListener("click", function() {
    window.location.href = "../Spel-Powerups/index2.html";  // Länkar till version 1 som ligger i version1-mappen
});

document.getElementById("version2").addEventListener("click", function() {
    window.location.href = "../Spel-enkel/index1.html";  // Länkar till version 2 som ligger i version2-mappen
});

// Skapa ormar och sätt slumpmässiga rörelser
function createRandomSnakes(numSnakes) {
    for (let i = 0; i < numSnakes; i++) {
        const snake = document.createElement('div');
        const randomColorClass = `snake${Math.floor(Math.random() * 4) + 1}`; // Slumpa en ormklass
        snake.classList.add('snake', randomColorClass);

        // Slumpmässig position (top, left)
        const startLeft = Math.random() * window.innerWidth;
        const startTop = Math.random() * window.innerHeight / 2; // Begränsar rörelsen till övre delen av skärmen
        snake.style.left = `${startLeft}px`;
        snake.style.top = `${startTop}px`;

        // Slumpmässig rörelsehastighet (5 till 10 sekunder)
        const randomSpeed = Math.random() * 5 + 5; // 5s till 10s
        snake.style.animationDuration = `${randomSpeed}s`;

        // Lägg till ormen på sidan
        document.body.appendChild(snake);

        // Starta rörelsen
        animateSnake(snake);
    }
}

function createRandomSnakes(numSnakes) {
    const colors = ['snake1', 'snake2', 'snake3', 'snake4', 'snake5']; // Ormfärger

    for (let i = 0; i < numSnakes; i++) {
        const snake = document.createElement('div');
        const randomColorClass = colors[Math.floor(Math.random() * colors.length)]; // Slumpmässig färg
        snake.classList.add('snake', randomColorClass);

        // Slumpmässig startposition (på y-axeln)
        const startTop = Math.random() * window.innerHeight; // Placera ormen på en slumpmässig höjd
        snake.style.top = `${startTop}px`;

        // Slumpmässig starttid (för att ormarna inte startar samtidigt)
        const delay = Math.random() * 100; // Mellan 0-5 sekunder
        snake.style.animationDelay = `-${delay}s`;

        // Lägg till ormen på sidan
        document.body.appendChild(snake);
    }
}

// Starta funktionen när sidan laddas
window.onload = () => {
    createRandomSnakes(20); // Skapa 5 ormar
};


// Animerar ormen horisontellt med slumpmässig rörelse
function animateSnake(snake) {
    const randomEndPosition = Math.random() * window.innerWidth; // Slumpmässig slutposition
    const randomDirection = Math.random() > 0.5 ? 1 : -1; // Slumpa riktning (vänster eller höger)

    snake.style.animation = `moveSnakeHorizontal ${Math.random() * 5 + 5}s linear infinite`;

    // Slumpmässig rörelse från vänster till höger eller vice versa
    snake.style.animationName = 'moveSnakeHorizontal';
    snake.style.left = `${randomDirection === 1 ? -100 : window.innerWidth + 100}px`; // Börja utanför skärmen
    snake.style.transition = `left ${Math.random() * 5 + 5}s ease-in-out`;

    // Slumpmässigt avslut för animation
    snake.style.transition = `left ${Math.random() * 10 + 5}s linear`;
    setInterval(() => {
        snake.style.left = `${randomEndPosition}px`;
    }, Math.random() * 1000 + 1000);
}

// Initiera ormar vid sidladdning
window.onload = () => {
    createRandomSnakes(5); // Skapa 5 ormar
}
