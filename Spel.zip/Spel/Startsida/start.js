document.getElementById("version1").addEventListener("click", function() {
    window.location.href = "Spel-Powerups/index.html";  // Länkar till version 1 som ligger i version1-mappen
});

document.getElementById("version2").addEventListener("click", function() {
    window.location.href = "Spel-enkel/index.html";  // Länkar till version 2 som ligger i version2-mappen
});
